from fastapi import FastAPI, Query
from typing import List, Optional
from sqlalchemy import create_engine, text
import os

# Azure MySQL connection details
DB_URL = "mysql+pymysql://trade_readonly:ReadOnlyPass123@hackathon-trade-flows-db.mysql.database.azure.com/trade_data?ssl_ca=/etc/ssl/cert.pem"
# Set up database connection
engine = create_engine(DB_URL)

app = FastAPI(title="Trade Data API")

### 1️⃣ Exports of product_code X from country A to all others ###
@app.get("/exports/")
def get_exports(
    product_code: int,
    exporter: int,
    start_year: Optional[int] = None,
    end_year: Optional[int] = None,
    metric: str = Query("value", enum=["value", "quantity"])
):
    """
    Returns exports of product_code X from country A to all others.
    Defaults to the most recent year if no range is provided.
    """
    with engine.connect() as conn:
        sql = f"""
        SELECT year, importer, {metric}
        FROM trade_table
        WHERE product_code = :product_code AND exporter = :exporter
        """
        params = {"product_code": product_code, "exporter": exporter}

        if start_year and end_year:
            sql += " AND year BETWEEN :start_year AND :end_year"
            params["start_year"] = start_year
            params["end_year"] = end_year
        else:
            sql += " ORDER BY year DESC LIMIT 1"

        result = conn.execute(text(sql), params).fetchall()
        return {"exports": [dict(row) for row in result]}

### 2️⃣ Total imports/exports of product_code X for country A by year ###
@app.get("/trade_totals/")
def get_trade_totals(
    product_code: int,
    country: int,
    trade_type: str = Query("export", enum=["export", "import"]),
    metric: str = Query("value", enum=["value", "quantity"])
):
    """
    Returns total imports or exports of product_code X for country A by year.
    """
    column = "exporter" if trade_type == "export" else "importer"

    with engine.connect() as conn:
        sql = f"""
        SELECT year, SUM({metric}) AS total_{metric}
        FROM trade_table
        WHERE product_code = :product_code AND {column} = :country
        GROUP BY year
        ORDER BY year DESC
        """
        result = conn.execute(text(sql), {"product_code": product_code, "country": country}).fetchall()
        return {"trade_totals": [dict(row) for row in result]}

### 3️⃣ Top exports/imports in year A for country X ###
@app.get("/top_trade/")
def get_top_trade(
    year: int,
    country: int,
    trade_type: str = Query("export", enum=["export", "import"]),
    metric: str = Query("value", enum=["value", "quantity"]),
    limit: int = 10
):
    """
    Returns top exports/imports for country X in year A.
    """
    column = "exporter" if trade_type == "export" else "importer"

    with engine.connect() as conn:
        sql = f"""
        SELECT product_code, SUM({metric}) AS total_{metric}
        FROM trade_table
        WHERE {column} = :country AND year = :year
        GROUP BY product_code
        ORDER BY total_{metric} DESC
        LIMIT :limit
        """
        result = conn.execute(text(sql), {"year": year, "country": country, "limit": limit}).fetchall()
        return {"top_trade": [dict(row) for row in result]}